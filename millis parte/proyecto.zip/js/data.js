// ===============================
// CATEGORÍAS
// ===============================
const categorias = [
  "Tortas Cuadradas",
  "Tortas Circulares",
  "Postres Individuales",
  "Productos Sin Azúcar",
  "Pastelería Tradicional",
  "Productos Sin Gluten",
  "Productos Veganos",
  "Tortas Especiales"
];

// ===============================
// PRODUCTOS
// ===============================
const productos = [
  {
    id: "TC001",
    categoria: "Tortas Cuadradas",
    nombre: "Torta Cuadrada de Chocolate",
    precio: 45000,
    imagen: "img/tortacuadradachocolate"
  },
  {
    id: "TC002",
    categoria: "Tortas Cuadradas",
    nombre: "Torta Cuadrada de Frutas",
    precio: 50000,
    imagen: "img/tortacuadradafrutas.jpg"
  },
  {
    id: "TT001",
    categoria: "Tortas Circulares",
    nombre: "Torta Circular de Vainilla",
    precio: 40000,
    imagen: "img/tortacircularvainilla.jpg"
  },
  {
    id: "TT002",
    categoria: "Tortas Circulares",
    nombre: "Torta Circular de Manjar",
    precio: 42000,
    imagen: "img/tortacircularmanjar.jpg"
  },
  {
    id: "PI001",
    categoria: "Postres Individuales",
    nombre: "Mousse de Chocolate",
    precio: 5000,
    imagen: "img/moussechocolate.jpg"
  },
  {
    id: "PI002",
    categoria: "Postres Individuales",
    nombre: "Tiramisú Clásico",
    precio: 5500,
    imagen: "img/tiramisu.jpg"
  },
  {
    id: "PSA001",
    categoria: "Productos Sin Azúcar",
    nombre: "Torta Sin Azúcar de Naranja",
    precio: 48000,
    imagen: "img/tortanaranja.jpg"
  },
  {
    id: "PSA002",
    categoria: "Productos Sin Azúcar",
    nombre: "Cheesecake Sin Azúcar",
    precio: 47000,
    imagen: "img/cheesecake.jpg"
  },
  {
    id: "PT001",
    categoria: "Pastelería Tradicional",
    nombre: "Empanada de Manzana",
    precio: 3000,
    imagen: "img/empanadamanzana.jpg"
  },
  {
    id: "PT002",
    categoria: "Pastelería Tradicional",
    nombre: "Tarta de Santiago",
    precio: 6000,
    imagen: "img/tartadesantiago.jpg"
  },
  {
    id: "PG001",
    categoria: "Productos Sin Gluten",
    nombre: "Brownie Sin Gluten",
    precio: 4000,
    imagen: "img/brownie.jpg"
  },
  {
    id: "PG002",
    categoria: "Productos Sin Gluten",
    nombre: "Pan Sin Gluten",
    precio: 3500,
    imagen: "img/pan.jpg"
  },
  {
    id: "PV001",
    categoria: "Productos Veganos",
    nombre: "Torta Vegana de Chocolate",
    precio: 50000,
    imagen: "img/tortavegchocolate.jpg"
  },
  {
    id: "PV002",
    categoria: "Productos Veganos",
    nombre: "Galletas Veganas de Avena",
    precio: 4500,
    imagen: "img/galletasavena.jpg"
  },
  {
    id: "TE001",
    categoria: "Tortas Especiales",
    nombre: "Torta Especial de Cumpleaños",
    precio: 55000,
    imagen: "img/tortacumpleaños.jpg"
  },
  {
    id: "TE002",
    categoria: "Tortas Especiales",
    nombre: "Torta Especial de Boda",
    precio: 60000,
    imagen: "img/tortaboda.jpg"
  }
];
